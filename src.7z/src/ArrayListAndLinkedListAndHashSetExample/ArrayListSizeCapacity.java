package ArrayListAndLinkedListAndHashSetExample;

import java.util.*; 

public class ArrayListSizeCapacity {
	  
	
	public static void main(String[] args) throws Exception  
	{  
	       
	    //ArrayList<Integer> al = new ArrayList<Integer>();  
		ArrayList<Integer> al = new ArrayList<Integer>(0);
	    al.add(19);
	    al.add(19);
	      
	    System.out.println("The size of the array is: " + al.size());  
	    for(int a:al) {
	    	 System.out.println("The size of the array is: " + a); 
	    }
	}  
	
}
