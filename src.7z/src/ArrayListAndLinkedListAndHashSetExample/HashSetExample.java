package ArrayListAndLinkedListAndHashSetExample;

import java.util.*;  

public class HashSetExample{  
public static void main(String args[]){  
//Creating HashSet and adding elements  
HashSet<String> set=new HashSet<String>();  
set.add("Ravi");  
set.add("Ravi"); 
set.add("Vijay");  
set.add("RAVI"); 
set.add("RaVi");
set.add("NULL");
set.add("NULL");
System.out.println(set);
//Traversing elements  
/*
 * Iterator<String> itr=set.iterator(); while(itr.hasNext()){
 * System.out.println(itr.next()); }
 */
for (String str : set) {  
System.out.println(str);  
}  
}  
} 