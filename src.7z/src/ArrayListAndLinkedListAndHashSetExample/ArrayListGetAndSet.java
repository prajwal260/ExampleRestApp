package ArrayListAndLinkedListAndHashSetExample;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListGetAndSet {
	  
	public static void main(String args[]){  
	//Creating HashSet and adding elements  
	ArrayList<String> set=new ArrayList<String>();  
	set.add("Ravi");  
	set.add("Ravi"); 
	set.add("Vijay");  
	set.add("aMar"); 
	set.add("RaVi");
	set.add("Amar");
	set.add("NULL");
	set.add("null");
	 Collections.sort(set); 
	System.out.println(set);
	//accessing the element    
	System.out.println("Returning element: "+set.get(1));//it will return the 2nd element, because index starts from 0  
	//changing the element  
	set.set(1,"Dates");  
	//Traversing elements  
	/*
	 * Iterator<String> itr=set.iterator(); while(itr.hasNext()){
	 * System.out.println(itr.next()); }
	 */
	for (String str : set) {  
	System.out.println(str);  
	}  
	}  
} 
