package Java8Extra;

public class MethodParameterReflection {

	int add(int a, int b){  
        return (a+b);  
    }  
    int mul(int a, int b){  
        return (b*a);  
    }  
}
