package Java8Extra;

import javax.script.*;  

public class EmbeddingJavaScriptCodeInJava {

	public static void main(String[] args) throws Exception{  
        // Creating script engine  
        ScriptEngine ee = new ScriptEngineManager().getEngineByName("Nashorn");  
        // Evaluating Nashorn code  
        ee.eval("print('Hello Nashorn');");  
    }  
}
