package Tree;

import java.util.*; 

public class TreeSetNavigableSetOperations {
   
	 public static void main(String args[]){  
	  TreeSet<String> set=new TreeSet<String>();  
	         set.add("A");  
	         set.add("B");  
	         set.add("C");  
	         set.add("D");  
	         set.add("E"); 
	         set.add("a");
	         set.add("c"); 
	         System.out.println("Initial Set: "+set);  
	           
	         System.out.println("Reverse Set: "+set.descendingSet());  
	           
	         System.out.println("NavigableSet Head Set: "+set.headSet("C", true)); 
	         System.out.println("SortedSet Head Set: "+set.headSet("C")); 
	          
	         System.out.println("NavigableSet SubSet: "+set.subSet("A", false, "E", true));  
	         System.out.println("SortedSet SubSet: "+set.subSet("A", "E"));
	           
	         System.out.println("NavigableSet TailSet: "+set.tailSet("C", false)); 
	         System.out.println("SortedSet TailSet: "+set.tailSet("C"));
	 }  
	
}
