package Extras;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Comparator;

public class StudentCompare {

	private int id;
	private String Name;
	private String Address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString() {
		return "StudentCompare [id=" + id + ", Name=" + Name + ", Address=" + Address + "]";
	}
	public StudentCompare(int id, String name, String address) {
		super();
		this.id = id;
		Name = name;
		Address = address;
	}
	public StudentCompare() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentCompare other = (StudentCompare) obj;
		if (Address == null) {
			if (other.Address != null)
				return false;
		} else if (!Address.equals(other.Address))
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (id != other.id)
			return false;
		return true;
	}
		public static void main(String[] args) {
			List<StudentCompare> studentCompare =  Arrays.asList(
					new StudentCompare(5, "Rajat", "Morena"),
					new StudentCompare(2, "Atul", "Banglore"),
					new StudentCompare(3, "Rajat", "Haryana"),
					new StudentCompare(4, "Gourav", "Indore"),
					new StudentCompare(1, "Rajat", "Morena")
				);
			System.out.println("Before Compare");
			for (StudentCompare studentCompare2 : studentCompare) {
				  System.out.println(studentCompare2);
			}
			System.out.println("After Compare");

			Comparator<StudentCompare> byName = (StudentCompare o1, StudentCompare o2) -> {
				/*
				 * if (o1.getName().equals(o2.getName())) { if
				 * (o1.getAddress().equals(o2.getAddress())) { return o1.getId() - o2.getId(); }
				 * else { return o1.getAddress().compareTo(o2.getAddress()); } }
				 * 
				 * else { return o1.getName().compareTo(o2.getName()); }
				 */
				if (o1.getName().equals(o2.getName()) && o1.getAddress().equals(o2.getAddress())) {
					return o1.getId() - o2.getId();
				} 
				else if(o1.getName().equals(o2.getName())) {
					 return o1.getAddress().compareTo(o2.getAddress());
				}
				else {
					 return o1.getName().compareTo(o2.getName());  
				}
			};
			 	
			/*
			 * Comparator<StudentCompare> byName = (StudentCompare o1, StudentCompare o2) ->
			 * { Comparator.comparing(StudentCompare :: getName)
			 * .thenComparing(StudentCompare :: getAddress) .thenComparing(StudentCompare ::
			 * getId);
			 * 
			 * };
			 */
					
		studentCompare.stream().sorted(byName).collect(Collectors.toList()).forEach(System.out::println);;
			
			
		}
	
}
