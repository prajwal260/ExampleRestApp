package Extras;

public class ReverseString {

//	emplist.stream().map(e->e.getEmpSalary()).sorted(Comparator.reverseOrder()).skip(1).findFirst();
//
//	emplist.stream()
//	                .filter((e -> e.getEmpSalary()>40000.00 ))
//	                .distinct()
//	                .sorted((e1,e2)-> e1.getEmpId()-e2.getEmpId())
//	                .sorted((e1,e2)-> e1.getEmpName().compareTo(e2.getEmpName()))
//	                .collect(Collectors.toList())
//	                .forEach(System.out::println);
//
//	emplist.stream().map(e->e.getEmpSalary()).sorted(Comparator.reverseOrder()).skip(2).findFirst();


	
	String str = "Rajat is a software engineer";
	char ch[] = str.toCharArray();
	String rev = "";
	
	for(int i=str.length(); i>=str.length()-1; i++) {
		rev= rev+ch[i];
		
		}
	return rev;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
	}

}
