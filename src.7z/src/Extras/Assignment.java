package Extras;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Assignment {

	private String Name;
	private int RollNo;
	private String City;
	
	public Assignment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Assignment(String name, int rollNo, String city) {
		super();
		Name = name;
		RollNo = rollNo;
		City = city;
	}

	@Override
	public String toString() {
		return "Assignment [Name=" + Name + ", RollNo=" + RollNo + ", City=" + City + "]";
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getRollNo() {
		return RollNo;
	}

	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}
	
	public static void main(String[] args) {
		List<Assignment> cityList = Arrays.asList(
					new Assignment("Rajat", 101, "Delhi"),
					new Assignment("Raj", 101, "Chennai"),
					new Assignment("Ram", 101, "Banglore"),
					new Assignment("Rajat", 101, "Pune"),
					new Assignment("Rajat", 101, "Chennai"),
					new Assignment("Rajat", 101, "Pune"),
					new Assignment("Rajat", 101, "Banglore"),
					new Assignment("Rajat", 101, "Delhi"),
					new Assignment("Rajat", 101, "Pune"),
					new Assignment("Rajat", 101, "Banglore"),
					new Assignment("Rajat", 101, "Delhi"),
					new Assignment("Rajat", 101, "Chennai")
				);
		Map<String, List<Assignment>> city = cityList.stream().collect(Collectors.groupingBy(b->b.getCity()));
		city.entrySet().stream().forEach(b-> System.out.println(b.getKey()+ ":" + b.getValue().size()));		
		
	}
}
