package Extras;

import java.util.regex.Pattern;

public class ASCII {

	public static void main(String[] args) {

		int charValue = 'A';
		
		System.out.println(charValue);
		
		String str = "ehgdghjsghdfj";
		Pattern.compile(".").matcher(str).results()
		    .forEach(System.out::println);
		
	}
}
