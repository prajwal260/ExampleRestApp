package Extras;

import java.util.*;

/*class Stude {    
	   int rollno;    
	   String name;    
	   int age;    
	    Stude(int rollno,String name,int age){    
	    this.rollno=rollno;    
	    this.name=name;    
	    this.age=age;    
	    }  
	    public int getRollno() {  
	        return rollno;  
	    }  
	    public void setRollno(int rollno) {  
	        this.rollno = rollno;  
	    }  
	    public String getName() {  
	        return name;  
	    }  
	  
	    public void setName(String name) {  
	        this.name = name;  
	    }  
	  
	    public int getAge() {  
	        return age;  
	    }  
	    public void setAge(int age) {  
	        this.age = age;  
	    }  
	    } */
public class ComparatorExampleNullsFirstAndNullsLast {

	public static void main(String args[]){    
		 ArrayList<Stude> al=new ArrayList<Stude>();    
		 al.add(new Stude(101,"Vijay",23));    
		 al.add(new Stude(106,"Ajay",27));    
		 al.add(new Stude(105,null,21));    
		 Comparator<Stude> cm1=Comparator.comparing(Stude::getName,Comparator.nullsFirst(String::compareTo));  
		  Collections.sort(al,cm1);  
		  System.out.println("Considers null to be less than non-null");  
		  for(Stude st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		     }  
		  Comparator<Stude> cm2=Comparator.comparing(Stude::getName,Comparator.nullsLast(String::compareTo));  
		  Collections.sort(al,cm2);  
		  System.out.println("Considers null to be greater than non-null");  
		  for(Stude st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		     }  
		 } 
}
