package Extras;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MinimumSwaps {

	/**
	 * @param popularity
	 * @return
	 */
	public static int minimumSwaps(List<Integer> popularity) {
		Integer[] arr = new Integer[popularity.size()];
        Collections.reverse(popularity);
        popularity.toArray(arr);
        for(int i=0; i<popularity.size(); i++){
            
        }
        int i = 0;
        int count = 0;
        int n = popularity.size();
        while(i<n){
            if(arr[i] != i+1){		// 2!=1, 4!=1
                swaparr(arr, i, arr[i]-1);		//0, 1
                count++;
            }
            else{
                i++;
            }
        }
        return count;
    }
    
	public static void swaparr(Integer[] arr, int i, int j){
        int temp = arr[i];		//temp=2
            arr[i]=arr[j];		//arr[0]=4,
            arr[j]=temp; 		//arr[1]=2,
    }

    /**
     * @param args
     */
    public static void main (String args[]) {
    	ArrayList<Integer> list = new ArrayList<>();
    	 list.add(3);
    	 list.add(1);
         list.add(4);
         list.add(2);
    	int c = minimumSwaps(list);
    	System.out.println(c);
    }
}
