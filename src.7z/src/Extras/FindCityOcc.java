package Extras;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FindCityOcc {

	String name;
	String rollno;
	String address;
	
	
	public FindCityOcc(String name, String rollno, String address) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public static void main (String args[]) {
		
		//ArrayList<FindCityOcc> list = new ArrayList<>()(
				List.of("bat", "Rajat", "Delhi");
				List.of("owl", "Raja", "mumbai");
				List.of("bat", "Raj", "kolkata");
				List.of("bat", "Ra", "chennai");
		//		);
		
	//	Map<String, Long> counts = list.stream().collect(Collectors.groupingBy(e -> e, Collectors.counting()));
		//int occurrences = Collections.frequency(animals, "bat");
		//System.err.println(occurrences);
	}
}
