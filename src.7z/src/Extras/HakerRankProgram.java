package Extras;

import java.util.Arrays;

public	class HakerRankProgram {
	
	public static void main(String[] args) {
		
		int[] arr = new int[] {5,4,5,3,2};
		int[] q   = new int[] {1,2,3,4,5};
		int[] sublist;
		
		for(int k=0; k<q.length; k++) {
			int count = 0;
			int max = 0;
			int num = q[k];
			
		for (int i=num-1; i<num; i++) {
			
			sublist = Arrays.copyOfRange(arr, i, arr.length);
			max = Arrays.stream(sublist).max().getAsInt();
			

		for(int j=0; j<sublist.length; j++) {
			System.out.print(sublist[j] + "\t");	
			if(max == sublist[j]) {
				count++;
			}
		}

		
		}
		System.out.print("\n");
		System.out.println("max" + max);
		System.out.println(count);
		}
	}
}