package Extras;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class checkCharOcc {
    public static void main(String[] args)
    {
    	String str = "rajat";
    	char count[] = str.toCharArray(); 
		
    	/*
		char ch[] = new char[str.length()];
		for (int i = 0; i < str.length(); i++) {
			ch[i] = str.charAt(i);
			for (int j = 0; j < str.length(); j++) {
				int c = 0;
				if (ch[i] == str.charAt(j)) {
					c++;
				}
			}
		}
		*/
	   
    	// By Using Java 8 Map
    			
    	Map<String, Long> result = Arrays.stream(str.split(""))
    			.map(String::toLowerCase)
    			.collect(Collectors.groupingBy(s -> s, LinkedHashMap::new, Collectors.counting()));  
    	System.out.println(result);  		 
    	
    	// By Using Java 8 Pattern
    		
		  Pattern.compile(".").matcher(str).results() .map(m ->
		  m.group().toLowerCase()) .collect(Collectors.groupingBy(s -> s,
		  LinkedHashMap::new, Collectors.counting())) .forEach((k, v) ->
		  System.out.println(k + " = " + v + " times"));
		 
    	// By Using Java 8 HashMap
    	  
    	  HashMap<Character, Integer> chOcc = new HashMap<>();
    	  for(int i=0; i<str.length(); i++) {
    		  if(chOcc.containsKey(str.charAt(i))) {
    			  int c = chOcc.get(str.charAt(i));
    			  chOcc.put(str.charAt(i), ++c);
    		  }
    		  else {
    			  chOcc.put(str.charAt(i), 1);
    		  }
    	  }
    	  	System.out.println(chOcc);  	  	 	  
    }
}

