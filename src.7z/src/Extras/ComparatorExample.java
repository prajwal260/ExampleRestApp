package Extras;

import java.util.*; 

class Stude {    
	   int rollno;    
	   String name;    
	  int age;    
	  Stude(int rollno,String name,int age){    
	    this.rollno=rollno;    
	    this.name=name;    
	    this.age=age;    
	    }  
	  
	    public int getRollno() {  
	        return rollno;  
	    }  
	    public void setRollno(int rollno) {  
	        this.rollno = rollno;  
	    }  
	  
	    public String getName() {  
	        return name;  
	    }  
	    public void setName(String name) {  
	        this.name = name;  
	    }  
	  
	    public int getAge() {  
	        return age;  
	    }  
	    public void setAge(int age) {  
	        this.age = age;  
	    }  
	  
	    } 
public class ComparatorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Stude> al=new ArrayList<Stude>();    
		  al.add(new Stude(101,"Vijay",23));    
		  al.add(new Stude(106,"Ajay",27));    
		  al.add(new Stude(105,"Jai",21));   
		//Sorting elements on the basis of name  
		  Comparator<Stude> cm1=Comparator.comparing(Stude::getName);  
		   Collections.sort(al,cm1);  
		   System.out.println("Sorting by Name");  
		   for(Stude st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		     }  
		   //Sorting elements on the basis of age  
		    Comparator<Stude> cm2=Comparator.comparing(Stude::getAge);  
		Collections.sort(al,cm2);  
		   System.out.println("Sorting by Age");  
		   for(Stude st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		     } 
	}

}
