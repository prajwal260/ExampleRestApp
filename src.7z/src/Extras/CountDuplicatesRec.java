package Extras;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CountDuplicatesRec {

	public static int numDuplicates(List<String> name, List<Integer> price, List<Integer> weight) {
        
        int dup = 0;
        boolean [] isdupli = new boolean[name.size()];
        for(int i = 0; i < name.size(); i++){			//
            for(int j = 0; j < i; j++ ){			   //
                if(!isdupli[j]){					  //
                	System.out.println(i + " " + j + !isdupli[j]);
                    if(name.get(i).equals(name.get(j)) && price.get(i) == price.get(j) && weight.get(i) == weight.get(j)){
                        isdupli[i] = true;
                        dup++;
                        System.out.println(dup);
                    }
                }
            }
            
        } 
        return dup; 
   //     Set<String> uniqueProducts = new HashSet<String>();
   // for(int i = 0; i< name.size(); i++)
   //     uniqueProducts.add(name.get(i) + " " + price.get(i) + " " + weight.get(i));    
   // return name.size() - uniqueProducts.size();
    }
	 public static void main (String args[]) {
	    	ArrayList<String> name = new ArrayList<>(List.of("Rajat", "Raj", "Rajat", "Raj"));
	    	ArrayList<Integer> price = new ArrayList<>(List.of(1, 5, 11, 5));
	    	ArrayList<Integer> weight = new ArrayList<>(List.of(10, 99, 10, 99));
	    	int c = numDuplicates(name, price, weight);
	    	System.out.println(c);
	    }
}
