package Extras;

import java.util.Arrays;

public class EmailReplace {
	
	public static String protectEmailAddress1(String emailAddress) {
	     String[] split = emailAddress.split("@");
	     
	     int n = split[0].length();
	     
	     char firstChar = split[0].charAt(0);
	     char lastChar = split[0].charAt(n-1);
	     
	     char[] emailNameCharacters = new char[n];
	     Arrays.fill(emailNameCharacters, '*');
	     
	     emailNameCharacters[0]=firstChar;
	     emailNameCharacters[n-1]=lastChar;

	     return (new String(emailNameCharacters) + "@" + split[1]);
	}
	
	public static void main(String[] args) {
		
		/*
		 * String str = "alexreply@other.domain.com"; str =
		 * str.replaceAll("(\\w{1,3})(\\w+)(@.*)", "$1****$3"); System.out.println(str);
		 */
		
		System.out.println(protectEmailAddress1("test@gmail.com"));
		
		// Second way
		String email = "martin@gmail.com";
        System.out.println("Original email address : "+email);
        
        String[] strArr1 = email.split("@");
        //martin = ["m","a","r","t","i","n"]
        String[] emailHead = strArr1[0].split(""); // emailHead = ["m","a","r","t","i","n"];
        String encryptedHead = emailHead[0]; // m
        for(int i=1;i<emailHead.length-1;i++) {
            encryptedHead+="*";                    // m + * + * + * + *
        }
        
        // encryptedHead = m****
        // encryptedHead = encryptedHead + "n";
        encryptedHead+=emailHead[emailHead.length-1]; // m**** = m****n
        String emailDomain = "@"+strArr1[strArr1.length-1]; // @......com

       System.out.println("Encrypted mail id : "+encryptedHead+emailDomain);
	 
	}
}
