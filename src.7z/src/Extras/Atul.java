package Extras;

public interface Atul {

	void print();      
}
