package Stream;

import java.util.*;  

class P{  
    int id;  
    String name;  
    float price;  
    public P(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  
	
public class CountMethodInCollection {

	  public static void main(String[] args) {  
	        List<P> PsList = new ArrayList<P>();  
	        //Adding Ps  
	        PsList.add(new P(1,"HP Laptop",25000f));  
	        PsList.add(new P(2,"Dell Laptop",30000f));  
	        PsList.add(new P(3,"Lenevo Laptop",28000f));  
	        PsList.add(new P(4,"Sony Laptop",28000f));  
	        PsList.add(new P(5,"Apple Laptop",90000f));  
	        // count number of Ps based on the filter  
	        long count = PsList.stream()  
	                    .filter(P->P.price<30000)  
	                    .count();  
	        System.out.println(count);  
	    } 
}
