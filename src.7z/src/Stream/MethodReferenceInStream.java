package Stream;

import java.util.*;  
import java.util.stream.Collectors;  

class ProductJ{  
    int id;  
    String name;  
    float price;  
      
    public ProductJ(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }
    public int getId() {  
        return id;  
    }  
    public String getName() {  
        return name;  
    }  
    public float getPrice() {  
        return price;  
    }  
}  
public class MethodReferenceInStream {

	 public static void main(String[] args) {  
         
	        List<ProductJ> ProductJsList = new ArrayList<ProductJ>();  
	          
	        //Adding ProductJs  
	        ProductJsList.add(new ProductJ(1,"HP Laptop",25000f));  
	        ProductJsList.add(new ProductJ(2,"Dell Laptop",30000f));  
	        ProductJsList.add(new ProductJ(3,"Lenevo Laptop",28000f));  
	        ProductJsList.add(new ProductJ(4,"Sony Laptop",28000f));  
	        ProductJsList.add(new ProductJ(5,"Apple Laptop",90000f));  
	          
	        List<Float> ProductJPriceList =   
	                ProductJsList.stream()  
	                            .filter(p -> p.price > 30000) // filtering data  
	                            .map(ProductJ::getPrice)         // fetching price by referring getPrice method  
	                            .collect(Collectors.toList());  // collecting as list  
	        System.out.println(ProductJPriceList);  
	    }  
}
