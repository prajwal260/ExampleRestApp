package Stream;

import java.util.*;  

class Produ{  
    int id;  
    String name;  
    float price;  
    public Produ(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  

public class FilteringAndIteratingCollection {

	public static void main(String[] args) {  
        List<Produ> productsList = new ArrayList<Produ>();  
        //Adding Products  
        productsList.add(new Produ(1,"HP Laptop",30000f));  
        productsList.add(new Produ(2,"Dell Laptop",30000f));  
        productsList.add(new Produ(3,"Lenevo Laptop",30000f));  
        productsList.add(new Produ(4,"Sony Laptop",28000f));  
        productsList.add(new Produ(5,"Apple Laptop",90000f));  
        // This is more compact approach for filtering data  
        productsList.stream()  
                             .filter(product -> product.price == 30000)  
                             .forEach(product -> System.out.println(product.name));    
    }  
}
