package Stream;

import java.util.*; 
import java.util.stream.*;

class Pro{  
    int id;  
    String name;  
    float price;  
    public Pro(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}

public class CollectorMethods {

	 public static void main(String[] args) {  
	        List<Pro> ProsList = new ArrayList<Pro>();  
	        //Adding Pros  
	        ProsList.add(new Pro(1,"HP Laptop",25000f));  
	        ProsList.add(new Pro(2,"Dell Laptop",30000f));  
	        ProsList.add(new Pro(3,"Lenevo Laptop",28000f));  
	        ProsList.add(new Pro(4,"Sony Laptop",28000f));  
	        ProsList.add(new Pro(5,"Apple Laptop",90000f));  
	        // Using Collectors's method to sum the prices.  
	        double totalPrice3 = ProsList.stream()  
	                        .collect(Collectors.summingDouble(Pro->Pro.price));  
	        System.out.println(totalPrice3);  
	          
	    } 
}
