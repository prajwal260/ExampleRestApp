package Stream;

import java.util.*;    

class Pr{    
    int id;    
    String name;    
    float price;    
    public Pr(int id, String name, float price) {    
        this.id = id;    
        this.name = name;    
        this.price = price;    
    }    
}  

public class FindMaxMin {

	public static void main(String[] args) {    
        List<Pr> PrsList = new ArrayList<Pr>();    
        //Adding Prs    
        PrsList.add(new Pr(1,"HP Laptop",25000f));    
        PrsList.add(new Pr(2,"Dell Laptop",30000f));    
        PrsList.add(new Pr(3,"Lenevo Laptop",28000f));    
        PrsList.add(new Pr(4,"Sony Laptop",28000f));    
        PrsList.add(new Pr(5,"Apple Laptop",90000f));    
        // max() method to get max Pr price     
        Pr PrA = PrsList.stream().max((Pr1, Pr2)->Pr1.price > Pr2.price ? 1: -1).get();    
        System.out.println(PrA.price);    
        // min() method to get min Pr price    
        Pr PrB = PrsList.stream().min((Pr1, Pr2)->Pr1.price > Pr2.price ? 1: -1).get();    
        System.out.println(PrB.price);    
            
    } 
}
