package LambdaExpression;

import java.util.*;

public class ForeachLoop {

	public static void main(String[] args) {  
        
        List<String> list=new ArrayList<String>();  
        list.add("ankit");  
        list.add("mayank");  
        list.add("irfan");  
        list.add("jai");  
          
        list.forEach(  
            (n)->System.out.println(n)  
        );  
        System.out.println();
        
        for (String s : list) {
        	System.out.println(s);
		}
    }  
}
