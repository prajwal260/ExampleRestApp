package LambdaExpression;

import java.util.*;
import java.util.stream.Stream;

class Produc{  
    int id;  
    String name;  
    float price;  
    public Produc(int id, String name, float price) {  
        super();  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
} 

public class FilterCollectionData {

	public static void main(String[] args) {  
        List<Produc> list=new ArrayList<Produc>();  
        list.add(new Produc(1,"Samsung A5",17000f));  
        list.add(new Produc(3,"Iphone 6S",65000f));  
        list.add(new Produc(2,"Sony Xperia",25000f));  
        list.add(new Produc(4,"Nokia Lumia",15000f));  
        list.add(new Produc(5,"Redmi4 ",26000f));  
        list.add(new Produc(6,"Lenevo Vibe",19000f));  
          
        // using lambda to filter data  
        Stream<Produc> filtered_data = list.stream().filter(p -> p.price > 20000);  
          
        // using lambda to iterate through collection  
        filtered_data.forEach(  
                Produc -> System.out.println(Produc.name+": "+Produc.price)  
        );  
    }  
}
