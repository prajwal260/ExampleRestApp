package MethodReferences;

import java.util.function.BiFunction;  

class Arithmet{  
public int add(int a, int b){  
return a+b;  
}  
} 

public class BiFunctionInstanceMethod {

	public static void main(String[] args) {  
		BiFunction<Integer, Integer, Integer>adder = new Arithmet()::add;  
		int result = adder.apply(10, 20);  
		System.out.println(result);  
		}  
}
