package MethodReferences;
    
public class ThreadInstanceMethod {

	public void printnMsg(){  
        System.out.println("Hello, this is instance method");  
    }  
	public static void main(String[] args) {  
	    Thread t2=new Thread(new ThreadInstanceMethod()::printnMsg);  
	        t2.start();       
	    }  
}
