package MethodReferences;

interface Saya{  
    void say();  
}

public class StaticMethod {

	public static void saySomething(){  
        System.out.println("Hello, this is static method.");  
    }  
    public static void main(String[] args) {  
        // Referring static method  
    	Saya sayable = StaticMethod::saySomething;  
        // Calling interface method  
        sayable.say();  
    }  
}
