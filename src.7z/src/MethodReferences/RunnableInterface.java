package MethodReferences;

public class RunnableInterface {

	public static void ThreadStatus(){  
        System.out.println("Thread is running...");  
    }  
    public static void main(String[] args) {  
        Thread t2=new Thread(RunnableInterface::ThreadStatus);  
        t2.start();       
    } 
}
