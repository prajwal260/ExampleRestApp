package Collectors;

import java.util.stream.Collectors;  
import java.util.List;  
import java.util.ArrayList; 

class Prod{  
    int id;  
    String name;  
    float price;  
      
    public Prod(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  

public class CollectorGettingProdAverage {

	  public static void main(String[] args) {  
	        List<Prod> ProdsList = new ArrayList<Prod>();  
	        //Adding Prods  
	        ProdsList.add(new Prod(1,"HP Laptop",25000f));  
	        ProdsList.add(new Prod(2,"Dell Laptop",30000f));  
	        ProdsList.add(new Prod(3,"Lenevo Laptop",28000f));  
	        ProdsList.add(new Prod(4,"Sony Laptop",28000f));  
	        ProdsList.add(new Prod(5,"Apple Laptop",90000f));  
	        Double average = ProdsList.stream()  
	                         .collect(Collectors.averagingDouble(p->p.price));  
	        System.out.println("Average price is: "+average);  
	    }  
}
