package Collectors;

import java.util.stream.Collectors;  
import java.util.List;  
import java.util.ArrayList;

class Produ{  
    int id;  
    String name;  
    float price;  
      
    public Produ(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
} 

public class CollectorsUsingSumMethod {

	public static void main(String[] args) {  
        List<Produ> ProdusList = new ArrayList<Produ>();  
        //Adding Produs  
        ProdusList.add(new Produ(1,"HP Laptop",25000f));  
        ProdusList.add(new Produ(2,"Dell Laptop",30000f));  
        ProdusList.add(new Produ(3,"Lenevo Laptop",28000f));  
        ProdusList.add(new Produ(4,"Sony Laptop",28000f));  
        ProdusList.add(new Produ(5,"Apple Laptop",90000f));  
        Double sumPrices =   
                ProdusList.stream()  
                            .collect(Collectors.summingDouble(x->x.price));  // collecting as list  
        System.out.println("Sum of prices: "+sumPrices);  
        Integer sumId =   
                ProdusList.stream().collect(Collectors.summingInt(x->x.id));  
        System.out.println("Sum of id's: "+sumId);  
    }  
}
