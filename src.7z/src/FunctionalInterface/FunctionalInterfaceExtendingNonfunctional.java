package FunctionalInterface;

interface Doable{  
    default void doIt(){  
        System.out.println("Do it now");  
    }  
}  
@FunctionalInterface  
interface Sayabl extends Doable{  
    void say(String msg);   // abstract method  
}

public class FunctionalInterfaceExtendingNonfunctional implements Sayabl{

	public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
    	FunctionalInterfaceExtendingNonfunctional fie = new FunctionalInterfaceExtendingNonfunctional();  
        fie.say("Hello there");  
        fie.doIt();  
    }  
}
