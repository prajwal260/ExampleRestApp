package FunctionalInterface;

@FunctionalInterface  
interface sayable{  
    void say(String msg);  
}  

public class FunctionalInterfac  implements sayable{

	   public void say(String msg){  
	        System.out.println(msg);  
	    }  
	    public static void main(String[] args) {  
	    	FunctionalInterfac fie = new FunctionalInterfac();  
	        fie.say("Hello there");  
	    }  
}
